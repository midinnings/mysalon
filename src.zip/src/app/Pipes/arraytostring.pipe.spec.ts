import { ArraytostringPipe } from './arraytostring.pipe';

describe('ArraytostringPipe', () => {
  it('create an instance', () => {
    const pipe = new ArraytostringPipe();
    expect(pipe).toBeTruthy();
  });
});
