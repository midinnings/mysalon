import { DaysagoPipe } from './daysago.pipe';

describe('DaysagoPipe', () => {
  it('create an instance', () => {
    const pipe = new DaysagoPipe();
    expect(pipe).toBeTruthy();
  });
});
