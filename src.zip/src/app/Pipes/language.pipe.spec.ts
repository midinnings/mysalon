import { LanguagePipe } from './language.pipe';

describe('LanguagePipe', () => {
  it('create an instance', () => {
    const pipe = new LanguagePipe();
    expect(pipe).toBeTruthy();
  });
});
