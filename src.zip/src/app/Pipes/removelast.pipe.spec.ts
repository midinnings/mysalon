import { RemovelastPipe } from './removelast.pipe';

describe('RemovelastPipe', () => {
  it('create an instance', () => {
    const pipe = new RemovelastPipe();
    expect(pipe).toBeTruthy();
  });
});
