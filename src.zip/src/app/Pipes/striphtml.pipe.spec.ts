import { StriphtmlPipe } from './striphtml.pipe';

describe('StriphtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new StriphtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
