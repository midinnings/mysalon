/*
 *  Diagnostic_Calendar.h
 *  Diagnostic Plugin - Calendar Module
 *
 *  Copyright (c) 2018 Working Edge Ltd.
 *  Copyright (c) 2012 AVANTIC ESTUDIO DE INGENIEROS
 */

#import <Cordova/CDV.h>
#import <Cordova/CDVPlugin.h>
#import "Diagnostic.h"

#import <EventKit/EventKit.h>


@interface Diagnostic_Calendar : CDVPlugin

@property (nonatomic) EKEventStore *eventStore;

- (void) getCalendarAuthorizationStatus: (CDVInvokedUrlCommand*)command;
- (void) isCalendarAuthorized: (CDVInvokedUrlCommand*)command;
- (void) requestCalendarAuthorization: (CDVInvokedUrlCommand*)command;

@end
